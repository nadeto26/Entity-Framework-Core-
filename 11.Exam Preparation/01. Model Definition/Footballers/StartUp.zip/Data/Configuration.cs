﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-EFFK5Q4;Database=FootballersExam;Trusted_Connection=True";
    }
}
