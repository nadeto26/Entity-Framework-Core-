﻿namespace _01._Student_System
{
    internal class Startup
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}