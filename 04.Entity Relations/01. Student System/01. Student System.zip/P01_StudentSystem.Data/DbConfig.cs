﻿namespace P01_StudentSystem.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString =
          @"Server=DESKTOP-EFFK5Q4;Database=School;Integrated Security=True;Encrypt=False;";
    }
}