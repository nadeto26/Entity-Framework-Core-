﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString =
          @"Server=DESKTOP-EFFK5Q4;Database=Trucks;Trusted_Connection=True";
    }
}
