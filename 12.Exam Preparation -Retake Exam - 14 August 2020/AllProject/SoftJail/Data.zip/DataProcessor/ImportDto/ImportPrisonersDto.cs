﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace SoftJail.DataProcessor.ImportDto
{
    [XmlType("Prisoners")]
    public class ImportPrisonersDto
    {
        [XmlAttribute("id")]
        public int Id { get; set; }
    }
}
