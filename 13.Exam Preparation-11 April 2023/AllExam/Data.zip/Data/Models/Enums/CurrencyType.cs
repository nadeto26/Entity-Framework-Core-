﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Invoices.Data.Models.Enums
{
    public enum CurrencyType
    {
        BGN,
        EUR,
        USD

    }
}
