﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Invoices.Data.Models.Enums
{
    public enum CategoryType
    {
        ADR, 
        Filters, 
        Lights, 
        Others, 
        Tyres

    }
}
